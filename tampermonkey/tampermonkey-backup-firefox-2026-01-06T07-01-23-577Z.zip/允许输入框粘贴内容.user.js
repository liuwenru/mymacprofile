// ==UserScript==
// @name         允许输入框粘贴内容
// @namespace    http://tampermonkey.net/
// @version      0.1
// @description  在所有网页上允许输入框粘贴内容
// @author       您的名字
// @match        *://*/*
// @grant        none
// ==/UserScript==

(function() {
    'use strict';

    // 方法 1: 移除 oncopy, oncut, onpaste 事件
    document.body.setAttribute('oncopy', '');
    document.body.setAttribute('oncut', '');
    document.body.setAttribute('onpaste', '');

    // 方法 2: 移除所有元素的事件监听器
    const removeEventListeners = (el) => {
        el.removeAttribute('onpaste');
        el.removeAttribute('oncopy');
        el.removeAttribute('oncut');
    };

    // 遍历所有元素
    const allElements = document.querySelectorAll('*');
    allElements.forEach(el => removeEventListeners(el));

    // 方法 3: 使用事件捕获阶段来覆盖事件
    document.addEventListener('copy', (e) => { e.stopPropagation(); }, true);
    document.addEventListener('paste', (e) => { e.stopPropagation(); }, true);
    document.addEventListener('cut', (e) => { e.stopPropagation(); }, true);

    // 方法 4: 更改样式，尝试解除限制
    const styles = `*:not(input):not(textarea) {
        -webkit-user-select: text !important;
        -moz-user-select: text !important;
        -ms-user-select: text !important;
        user-select: text !important;
    }`;

    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);

    // 方法 5: 解除可能被设置的只读属性
    const inputs = document.querySelectorAll('input, textarea');
    inputs.forEach(input => {
        input.removeAttribute('readonly');
        input.removeAttribute('disabled');
    });

    // 方法 6: 使用定时器不断尝试解除限制
    setInterval(() => {
        allElements.forEach(el => removeEventListeners(el));
        inputs.forEach(input => {
            input.removeAttribute('readonly');
            input.removeAttribute('disabled');
        });
    }, 1000); // 每秒尝试一次

})();